<?php
/**
 * CyberSource Secure Acceptance payment driver for VikRentCar Pro.
 * Extends standard JPayment gateway adapter.
 */

defined('ABSPATH') || exit;

JLoader::import('adapter.payment.payment');

require_once dirname(__DIR__) . '/includes/class-cybersource-signer.php';
require_once dirname(__DIR__) . '/includes/class-cybersource-reasons.php';

class VikRentCarCyberSourcePayment extends JPayment
{
    const SA_URL_TEST = 'https://testsecureacceptance.cybersource.com/pay';
    const SA_URL_LIVE = 'https://secureacceptance.cybersource.com/pay';

    public function __construct($caller, $order, $params = array())
    {
        parent::__construct($caller, $order, $params);
    }

    /**
     * Define admin settings shown in VikRentCar Payments manager.
     */
    protected function buildAdminParameters()
    {
        return array(
            'mode' => array(
                'type'    => 'select',
                'label'   => 'Environment Mode',
                'options' => array(
                    'simulator' => 'Simulator Mode (Local Testing)',
                    'sandbox'   => 'CyberSource Sandbox',
                    'live'      => 'Live Production (Absa Bank)',
                ),
                'default' => 'simulator',
            ),
            'sa_profile_id' => array(
                'type'    => 'text',
                'label'   => 'Secure Acceptance Profile ID',
                'default' => '',
            ),
            'sa_access_key' => array(
                'type'    => 'text',
                'label'   => 'Access Key',
                'default' => '',
            ),
            'sa_secret_key' => array(
                'type'    => 'password',
                'label'   => 'Secret Key',
                'default' => '',
            ),
        );
    }

    /**
     * Prepare order parameters and display payment button on checkout.
     */
    protected function beginTransaction()
    {
        $order        = $this->getOrder();
        $totalToPay   = (float) $this->get('total_to_pay', $this->get('order_total', 0));
        $currencySymb = $this->get('currency_symb', '$');
        $currencyCode = $this->get('transaction_currency', 'USD');
        $notifyUrl    = $this->get('notify_url');
        $mode         = defined('VRC_CS_MODE') ? VRC_CS_MODE : $this->getParam('mode', get_option('vrc_cs_mode', 'simulator'));
        $isSimulator  = ($mode === 'simulator');

        $orderSid     = isset($order['order']['sid']) ? $order['order']['sid'] : $this->get('sid');
        $orderTs      = isset($order['order']['ts']) ? $order['order']['ts'] : $this->get('ts');

        // Extract customer email (VikRentCar uses custmail in orders table)
        $custEmail = '';
        if (!empty($order['order']['custmail'])) {
            $custEmail = $order['order']['custmail'];
        } elseif (!empty($order['order']['email'])) {
            $custEmail = $order['order']['email'];
        } elseif (!empty($order['custmail'])) {
            $custEmail = $order['custmail'];
        } elseif ($this->get('custmail')) {
            $custEmail = $this->get('custmail');
        } elseif ($this->get('email')) {
            $custEmail = $this->get('email');
        } else {
            $custEmail = 'customer@example.com';
        }

        // Extract customer name
        $custName = '';
        if (!empty($order['order']['nominative'])) {
            $custName = $order['order']['nominative'];
        } elseif (!empty($order['order']['nominativo'])) {
            $custName = $order['order']['nominativo'];
        } elseif (!empty($order['nominative'])) {
            $custName = $order['nominative'];
        } elseif ($this->get('nominative')) {
            $custName = $this->get('nominative');
        } else {
            $custName = 'Valued Customer';
        }

        $nameParts = explode(' ', trim($custName), 2);
        $firstName = !empty($nameParts[0]) ? $nameParts[0] : 'Customer';
        $lastName  = !empty($nameParts[1]) ? $nameParts[1] : 'Rental';

        // Extract billing details for Decision Manager and 3D Secure
        $phone   = !empty($order['order']['phone']) ? $order['order']['phone'] : (!empty($order['phone']) ? $order['phone'] : '');
        $country = !empty($order['order']['country']) ? $order['order']['country'] : (!empty($order['country']) ? $order['country'] : '');
        $address = '';
        $city    = '';
        $postalCode = '';

        $custdata = !empty($order['order']['custdata']) ? $order['order']['custdata'] : (!empty($order['custdata']) ? $order['custdata'] : '');
        if (!empty($custdata)) {
            $lines = explode("\n", $custdata);
            foreach ($lines as $line) {
                $parts = explode(':', trim($line), 2);
                if (count($parts) === 2) {
                    $k = strtolower(trim($parts[0]));
                    $v = trim($parts[1]);
                    if ($k === 'address') $address = $v;
                    if ($k === 'city') $city = $v;
                    if ($k === 'zip code' || $k === 'postal code') $postalCode = $v;
                    if ($k === 'phone' && empty($phone)) $phone = $v;
                }
            }
        }

        // Enqueue payment card styling
        $cssUrl = plugins_url('assets/cybersource.css', dirname(__FILE__));
        echo '<link rel="stylesheet" href="' . esc_url($cssUrl) . '?v=' . time() . '" type="text/css" media="all" />';

        $postUrl = ($mode === 'live') ? self::SA_URL_LIVE : self::SA_URL_TEST;
        $params  = array();

        if (!$isSimulator) {
            $profileId = defined('VRC_CS_SA_PROFILE_ID') ? VRC_CS_SA_PROFILE_ID : trim($this->getParam('sa_profile_id', get_option('vrc_cs_sa_profile_id', '')));
            $accessKey = defined('VRC_CS_SA_ACCESS_KEY') ? VRC_CS_SA_ACCESS_KEY : trim($this->getParam('sa_access_key', get_option('vrc_cs_sa_access_key', '')));
            $secretKey = defined('VRC_CS_SA_SECRET_KEY') ? VRC_CS_SA_SECRET_KEY : trim($this->getParam('sa_secret_key', get_option('vrc_cs_sa_secret_key', '')));

            // Receipt return URL with order identifiers
            $receiptUrl = $notifyUrl;
            $sep = (strpos($receiptUrl, '?') !== false) ? '&' : '?';
            $receiptUrl .= $sep . 'sid=' . urlencode($orderSid) . '&ts=' . urlencode($orderTs);

            // Cancel URL redirects customer back to order review page
            $cancelUrl = $this->get('error_url');
            if (empty($cancelUrl)) {
                $cancelUrl = site_url('index.php?option=com_vikrentcar&view=order&sid=' . urlencode($orderSid) . '&ts=' . urlencode($orderTs));
            }

            // Build parameters required by CyberSource Secure Acceptance
            $rawParams = array(
                'access_key'                   => $accessKey,
                'profile_id'                   => $profileId,
                'transaction_uuid'             => uniqid('vrc_', true),
                'signed_date_time'             => gmdate("Y-m-d\TH:i:s\Z"),
                'locale'                       => 'en',
                'transaction_type'             => 'sale',
                'reference_number'             => (string)$orderSid,
                'amount'                       => number_format($totalToPay, 2, '.', ''),
                'currency'                     => strtoupper($currencyCode),
                'payment_method'               => 'card',
                'bill_to_forename'             => $firstName,
                'bill_to_surname'              => $lastName,
                'bill_to_email'                => $custEmail,
                'override_custom_receipt_page' => $receiptUrl,
                'override_custom_cancel_page'  => $cancelUrl,
            );

            // Pass customer billing info to Decision Manager and Payer Auth
            if (!empty($phone)) {
                $rawParams['bill_to_phone'] = substr($phone, 0, 15);
            }
            if (!empty($address)) {
                $rawParams['bill_to_address_line1'] = substr($address, 0, 60);
            }
            if (!empty($city)) {
                $rawParams['bill_to_address_city'] = substr($city, 0, 50);
            }
            if (!empty($postalCode)) {
                $rawParams['bill_to_address_postal_code'] = substr($postalCode, 0, 10);
            }
            if (!empty($country)) {
                $c = strtoupper(trim($country));
                if (strlen($c) === 3) {
                    $map = array('SYC' => 'SC', 'LKA' => 'LK', 'USA' => 'US', 'GBR' => 'GB', 'FRA' => 'FR', 'DEU' => 'DE', 'ITA' => 'IT', 'ZAF' => 'ZA', 'ARE' => 'AE', 'IND' => 'IN');
                    $c   = isset($map[$c]) ? $map[$c] : substr($c, 0, 2);
                }
                $rawParams['bill_to_address_country'] = substr($c, 0, 2);
            }

            // Generate HMAC-SHA256 signature
            $params = VRC_CyberSource_Signer::signParams($rawParams, $secretKey);
        }

        // Render customer-facing UI
        $templatePath = dirname(__DIR__) . '/templates/payment-form.php';
        if (file_exists($templatePath)) {
            include $templatePath;
        }
    }

    /**
     * Validate payment callback from CyberSource or simulator.
     */
    protected function validateTransaction(JPaymentStatus &$status)
    {
        $order      = $this->getOrder();
        $totalToPay = (float) $this->get('total_to_pay', $this->get('order_total', 0));
        $currency   = strtoupper($this->get('transaction_currency', 'USD'));
        $mode       = defined('VRC_CS_MODE') ? VRC_CS_MODE : $this->getParam('mode', get_option('vrc_cs_mode', 'simulator'));

        // Prevent duplicate processing if already marked confirmed and paid
        $existingStatus = isset($order['order']['status']) ? strtolower($order['order']['status']) : '';
        $existingPaid   = isset($order['order']['totpaid']) ? (float)$order['order']['totpaid'] : 0.0;
        if ($existingStatus === 'confirmed' && $existingPaid >= $totalToPay && $totalToPay > 0) {
            $status->verified(true);
            $status->paid($existingPaid);
            $status->setLog("Notice: Duplicate callback received for already confirmed booking.");
            return;
        }

        // Handle offline simulator mode
        if ($mode === 'simulator' || (isset($_POST['cs_mode']) && $_POST['cs_mode'] === 'simulator')) {
            $txnId = 'SIM-CS-' . strtoupper(bin2hex(random_bytes(5)));
            $log = sprintf(
                "--- CyberSource Transaction Result ---\nStatus: AUTHORIZED (Simulator Mode)\nTransaction ID: %s\nAmount Paid: %s %s\nTimestamp: %s\nVerified: YES",
                $txnId,
                number_format($totalToPay, 2),
                $currency,
                current_time('mysql')
            );

            $status->verified(true);
            $status->paid($totalToPay);
            $status->setLog($log);
            $status->setData('transaction', array(
                'id'       => $txnId,
                'provider' => 'CyberSource Simulator',
                'amount'   => $totalToPay,
                'currency' => $currency,
            ));
            return;
        }

        // Process Secure Acceptance response
        if (isset($_POST['decision'])) {
            $decision   = strtoupper(sanitize_text_field($_POST['decision']));
            $txnId      = isset($_POST['transaction_id']) ? sanitize_text_field($_POST['transaction_id']) : '';
            $authAmt    = isset($_POST['auth_amount']) ? (float)$_POST['auth_amount'] : (isset($_POST['req_amount']) ? (float)$_POST['req_amount'] : $totalToPay);
            $respCurr   = isset($_POST['req_currency']) ? strtoupper(sanitize_text_field($_POST['req_currency'])) : $currency;
            $reasonCode = isset($_POST['reason_code']) ? sanitize_text_field($_POST['reason_code']) : '';
            $message    = isset($_POST['message']) ? sanitize_text_field($_POST['message']) : '';
            $secretKey  = defined('VRC_CS_SA_SECRET_KEY') ? VRC_CS_SA_SECRET_KEY : trim($this->getParam('sa_secret_key', get_option('vrc_cs_sa_secret_key', '')));

            // Verify incoming signature to guard against tampering
            if (!empty($secretKey)) {
                $isSignatureValid = VRC_CyberSource_Signer::verifySignature($_POST, $secretKey);
                if (!$isSignatureValid) {
                    $status->verified(false);
                    $status->setLog('Security Alert: Callback signature mismatch.');
                    return;
                }
            }

            // Ensure paid amount is not less than the order total
            if ($authAmt < ($totalToPay - 0.05)) {
                $status->verified(false);
                $status->setLog(sprintf(
                    "Security Alert: Paid amount (%s %s) does not match required total (%s %s).",
                    $authAmt, $respCurr, $totalToPay, $currency
                ));
                return;
            }

            // Check gateway decision
            if ($decision === 'ACCEPT') {
                $log = sprintf(
                    "--- CyberSource Secure Acceptance Approved ---\nDecision: ACCEPT\nTransaction ID: %s\nAmount Paid: %s %s\nReason Code: %s\nTimestamp: %s\nVerified: YES",
                    $txnId,
                    number_format($authAmt, 2),
                    $respCurr,
                    $reasonCode ? $reasonCode : '100',
                    current_time('mysql')
                );

                $status->verified(true);
                $status->paid($authAmt);
                $status->setLog($log);
                $status->setData('transaction', array(
                    'id'       => $txnId,
                    'provider' => 'CyberSource Secure Acceptance',
                    'amount'   => $authAmt,
                    'currency' => $respCurr,
                ));
            } else {
                // Card declined, cancelled, or error
                $friendlyReason = VRC_CyberSource_Reasons::translate($reasonCode, $message);
                $log = sprintf(
                    "--- CyberSource Payment Not Approved ---\nDecision: %s\nReason Code: %s\nDetails: %s\nTransaction ID: %s\nTimestamp: %s",
                    $decision,
                    $reasonCode,
                    $friendlyReason,
                    $txnId,
                    current_time('mysql')
                );
                $status->verified(false);
                $status->setLog($log);
            }
            return;
        }

        $status->verified(false);
        $status->setLog('Error: Missing callback parameters from CyberSource.');
    }

    /**
     * Finalize checkout, enqueue flash notice, and redirect.
     */
    protected function complete($res)
    {
        $app = JFactory::getApplication();
        if ($res) {
            $txnId = isset($_POST['transaction_id']) ? sanitize_text_field($_POST['transaction_id']) : '';
            $msg   = 'Payment Successful! Your booking is confirmed and approved by CyberSource.';
            if (!empty($txnId)) {
                $msg .= ' (Transaction ID: ' . $txnId . ')';
            }
            $app->enqueueMessage($msg, 'message');

            $returnUrl = $this->get('return_url');
            if (!empty($returnUrl)) {
                $app->redirect($returnUrl);
                exit;
            }
        } else {
            $reasonCode = isset($_POST['reason_code']) ? sanitize_text_field($_POST['reason_code']) : '';
            $message    = isset($_POST['message']) ? sanitize_text_field($_POST['message']) : '';
            $userMsg    = VRC_CyberSource_Reasons::translate($reasonCode, $message);

            $app->enqueueMessage('Payment was not completed: ' . $userMsg . ' Please try again or use another card.', 'error');

            $errorUrl = $this->get('error_url');
            if (!empty($errorUrl)) {
                $app->redirect($errorUrl);
                exit;
            }
        }
    }

    public function isRefundSupported()
    {
        return false;
    }
}