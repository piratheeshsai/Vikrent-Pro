<?php
/**
 * Plugin Name: VikRentCar CyberSource Gateway
 * Plugin URI:  https://valuecarseychelles.com
 * Description: CyberSource Secure Acceptance (Hosted Checkout) payment gateway for VikRentCar Pro.
 * Version:     2.0.0
 * Author:      Value Car Development Team
 * Text Domain: vikrentcar-cybersource
 */

defined('ABSPATH') || exit;

define('VIKRENTCAR_CYBERSOURCE_VERSION', '2.0.0');
define('VIKRENTCAR_CYBERSOURCE_DIR', plugin_dir_path(__FILE__));
define('VIKRENTCAR_CYBERSOURCE_URL', plugin_dir_url(__FILE__));

// Load core helper modules
require_once VIKRENTCAR_CYBERSOURCE_DIR . 'includes/class-cybersource-signer.php';
require_once VIKRENTCAR_CYBERSOURCE_DIR . 'includes/class-cybersource-reasons.php';

// Register payment gateway driver with VikRentCar
add_filter('get_supported_payments_vikrentcar', function($drivers) {
    if (!is_array($drivers)) {
        $drivers = array();
    }
    $drivers[] = 'cybersource';
    return array_unique($drivers);
});

// Load the payment driver class when requested by VikRentCar dispatcher
add_action('load_payment_gateway_vikrentcar', function(&$drivers, $payment) {
    if ($payment === 'cybersource' || $payment === 'cybersource.php') {
        require_once VIKRENTCAR_CYBERSOURCE_DIR . 'driver/cybersource.php';
        $drivers[] = 'VikRentCarCyberSourcePayment';
    }
}, 10, 2);

// Synchronize gateway settings with VikRentCar's payment table
function vrc_cs_ensure_database_record() {
    global $wpdb;
    $table = $wpdb->prefix . 'vikrentcar_gpayments';

    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
        return;
    }

    $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM `$table` WHERE `file` = %s", 'cybersource.php'));

    $title         = get_option('vrc_cs_title', 'Credit Card (Absa / CyberSource)');
    $mode          = get_option('vrc_cs_mode', 'simulator');
    $enabled       = get_option('vrc_cs_enabled', '1');
    $sa_profile_id = get_option('vrc_cs_sa_profile_id', '');
    $sa_access_key = get_option('vrc_cs_sa_access_key', '');
    $sa_secret_key = get_option('vrc_cs_sa_secret_key', '');

    $params = json_encode(array(
        'mode'          => $mode,
        'sa_profile_id' => $sa_profile_id,
        'sa_access_key' => $sa_access_key,
        'sa_secret_key' => $sa_secret_key,
    ));

    $note = '<p>Pay securely with Visa, Mastercard, or American Express with 3D Secure OTP verification powered by Absa Bank & CyberSource.</p>';

    if (!$existing) {
        $wpdb->insert($table, array(
            'name'         => $title,
            'file'         => 'cybersource.php',
            'published'    => ($enabled === '1' ? 1 : 0),
            'note'         => $note,
            'charge'       => 0.00,
            'setconfirmed' => 0,
            'shownotealw'  => 0,
            'val_pcent'    => 1,
            'ch_disc'      => 1,
            'params'       => $params,
            'ordering'     => 1,
            'outposition'  => 'top',
        ));
    } else {
        $wpdb->update($table, array(
            'name'         => $title,
            'published'    => ($enabled === '1' ? 1 : 0),
            'note'         => $note,
            'params'       => $params,
        ), array('id' => $existing->id));
    }
}
add_action('init', 'vrc_cs_ensure_database_record');

// Register dedicated "Online Booking Admin" role for client
function vrc_cs_register_booking_admin_role() {
    $cap = 'manage_booking_gateway';

    $admin = get_role('administrator');
    if ($admin && !$admin->has_cap($cap)) {
        $admin->add_cap($cap);
    }

    if (!get_role('online_booking_admin')) {
        add_role(
            'online_booking_admin',
            'Online Booking Admin',
            array(
                'read'                   => true,
                'upload_files'           => true,
                'manage_booking_gateway' => true,
                'com_vikrentcar_manage'  => true,
            )
        );
    } else {
        $role = get_role('online_booking_admin');
        if ($role) {
            if (!$role->has_cap($cap)) $role->add_cap($cap);
            if (!$role->has_cap('com_vikrentcar_manage')) $role->add_cap('com_vikrentcar_manage');
        }
    }
}
add_action('init', 'vrc_cs_register_booking_admin_role');


// Add settings page under VikRentCar admin menu
add_action('admin_menu', function() {
    // Allow users with VikRentCar management permission or administrators
    $cap = current_user_can('com_vikrentcar_manage') ? 'com_vikrentcar_manage' : (current_user_can('manage_booking_gateway') ? 'manage_booking_gateway' : 'manage_options');

    if (class_exists('VikRentCarBody')) {
        add_submenu_page(
            'vikrentcar',
            'Dashboard',
            'Dashboard',
            $cap,
            'vikrentcar',
            array('VikRentCarBody', 'getHtml')
        );
    }

    add_submenu_page(
        'vikrentcar',
        'CyberSource Gateway',
        'CyberSource Gateway',
        $cap,
        'vikrentcar-cybersource',
        'vrc_cs_render_admin_page'
    );

    add_options_page(
        'VikRentCar CyberSource',
        'CyberSource VikRentCar',
        'manage_booking_gateway',
        'vikrentcar-cybersource',
        'vrc_cs_render_admin_page'
    );
}, 99);

// Render the CyberSource configuration page
function vrc_cs_render_admin_page() {
    if (!current_user_can('manage_options') && !current_user_can('com_vikrentcar_manage') && !current_user_can('manage_booking_gateway')) {
        return;
    }

    $saved = false;
    if (isset($_POST['vrc_cs_save_settings']) && check_admin_referer('vrc_cs_save_action', 'vrc_cs_nonce')) {
        update_option('vrc_cs_enabled', isset($_POST['vrc_cs_enabled']) ? '1' : '0');
        update_option('vrc_cs_title', sanitize_text_field($_POST['vrc_cs_title']));
        update_option('vrc_cs_mode', sanitize_text_field($_POST['vrc_cs_mode']));
        update_option('vrc_cs_sa_profile_id', sanitize_text_field($_POST['vrc_cs_sa_profile_id']));
        update_option('vrc_cs_sa_access_key', sanitize_text_field($_POST['vrc_cs_sa_access_key']));
        update_option('vrc_cs_sa_secret_key', sanitize_text_field($_POST['vrc_cs_sa_secret_key']));

        vrc_cs_ensure_database_record();
        $saved = true;
    }

    $enabled       = get_option('vrc_cs_enabled', '1');
    $title         = get_option('vrc_cs_title', 'Credit Card (Absa / CyberSource)');
    $mode          = get_option('vrc_cs_mode', 'simulator');
    $sa_profile_id = get_option('vrc_cs_sa_profile_id', '');
    $sa_access_key = get_option('vrc_cs_sa_access_key', '');
    $sa_secret_key = get_option('vrc_cs_sa_secret_key', '');
    ?>
    <div class="wrap" style="max-width: 900px; margin-top: 25px;">
        <h1 style="display: flex; align-items: center; gap: 12px; margin-bottom: 8px;">
            <span style="background: #1e3a8a; color: white; padding: 6px 14px; border-radius: 6px; font-size: 16px; font-weight: 700;">CyberSource</span>
            Absa Bank Secure Acceptance Gateway
        </h1>
        <p style="color: #64748b; font-size: 14px; margin-top: 0;">
            Accept Visa, Mastercard, and American Express with automatic 3D Secure / OTP verification via CyberSource Hosted Checkout.
        </p>

        <?php if ($saved) : ?>
            <div class="notice notice-success is-dismissible" style="border-left-color: #10b981; padding: 12px 18px;">
                <p style="margin: 0; font-size: 14px;"><strong>Settings Saved!</strong> Gateway configuration updated and synced with VikRentCar Pro.</p>
            </div>
        <?php endif; ?>

        <!-- Quick Gateway Status Indicator -->
        <div style="background: #ffffff; padding: 16px 22px; border-radius: 8px; border: 1px solid #e2e8f0; margin: 20px 0; display: flex; justify-content: space-between; align-items: center;">
            <div>
                <strong style="color: #1e293b;">Gateway Status:</strong>
                <?php if ($enabled === '1') : ?>
                    <span style="background: #dcfce7; color: #15803d; padding: 4px 12px; border-radius: 20px; font-weight: 600; font-size: 13px; margin-left: 8px;">Active &amp; Published</span>
                <?php else : ?>
                    <span style="background: #fee2e2; color: #b91c1c; padding: 4px 12px; border-radius: 20px; font-weight: 600; font-size: 13px; margin-left: 8px;">Disabled</span>
                <?php endif; ?>
            </div>
            <div style="font-size: 13px;">
                <span style="color: #64748b;">Method:</span>
                <strong style="color: #1e3a8a; margin-right: 15px;">Secure Acceptance (Hosted Checkout)</strong>
                <span style="color: #64748b;">Mode:</span>
                <strong style="color: #0284c7; text-transform: uppercase;"><?php echo esc_html($mode); ?></strong>
            </div>
        </div>

        <form method="POST" action="">
            <?php wp_nonce_field('vrc_cs_save_action', 'vrc_cs_nonce'); ?>

            <div style="background: #ffffff; padding: 26px; border-radius: 10px; border: 1px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
                <h3 style="margin-top: 0; color: #0f172a; border-bottom: 2px solid #f1f5f9; padding-bottom: 10px;">1. General Settings</h3>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="vrc_cs_enabled">Enable Gateway</label></th>
                        <td>
                            <label style="font-weight: 600; color: #1e293b;">
                                <input type="checkbox" id="vrc_cs_enabled" name="vrc_cs_enabled" value="1" <?php checked($enabled, '1'); ?> />
                                Enable CyberSource at checkout in VikRentCar
                            </label>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row"><label for="vrc_cs_title">Title at Checkout</label></th>
                        <td>
                            <input type="text" id="vrc_cs_title" name="vrc_cs_title" value="<?php echo esc_attr($title); ?>" class="regular-text" style="width: 100%; max-width: 450px;" required />
                        </td>
                    </tr>

                    <tr>
                        <th scope="row"><label for="vrc_cs_mode">Environment Mode</label></th>
                        <td>
                            <select id="vrc_cs_mode" name="vrc_cs_mode" style="width: 100%; max-width: 450px;">
                                <option value="simulator" <?php selected($mode, 'simulator'); ?>>Simulator Mode (Local Testing)</option>
                                <option value="sandbox" <?php selected($mode, 'sandbox'); ?>>CyberSource Sandbox</option>
                                <option value="live" <?php selected($mode, 'live'); ?>>Live Production</option>
                            </select>
                        </td>
                    </tr>
                </table>

                <h3 style="margin-top: 25px; color: #0f172a; border-bottom: 2px solid #f1f5f9; padding-bottom: 10px;">2. Secure Acceptance Credentials</h3>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="vrc_cs_sa_profile_id">Profile ID</label></th>
                        <td>
                            <input type="text" id="vrc_cs_sa_profile_id" name="vrc_cs_sa_profile_id" value="<?php echo esc_attr($sa_profile_id); ?>" class="regular-text" style="width: 100%; max-width: 450px;" placeholder="e.g. car_rental_checkout" />
                            <p class="description">Your CyberSource Secure Acceptance Profile ID.</p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row"><label for="vrc_cs_sa_access_key">Access Key</label></th>
                        <td>
                            <input type="text" id="vrc_cs_sa_access_key" name="vrc_cs_sa_access_key" value="<?php echo esc_attr($sa_access_key); ?>" class="regular-text" style="width: 100%; max-width: 450px;" placeholder="e.g. 7f9a8b2c..." />
                            <p class="description">The Access Key generated under your Profile's Security Keys.</p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row"><label for="vrc_cs_sa_secret_key">Secret Key</label></th>
                        <td>
                            <input type="password" id="vrc_cs_sa_secret_key" name="vrc_cs_sa_secret_key" value="<?php echo esc_attr($sa_secret_key); ?>" class="regular-text" style="width: 100%; max-width: 450px;" />
                            <p class="description">The Secret Key used to generate secure HMAC-SHA256 signatures.</p>
                        </td>
                    </tr>
                </table>

                <p class="submit" style="margin-top: 25px; padding-top: 15px; border-top: 1px solid #f1f5f9;">
                    <button type="submit" name="vrc_cs_save_settings" class="button button-primary" style="padding: 6px 22px; height: auto; font-size: 14px; font-weight: 600;">
                        Save CyberSource Settings
                    </button>
                </p>
            </div>
        </form>
    </div>
    <?php
}