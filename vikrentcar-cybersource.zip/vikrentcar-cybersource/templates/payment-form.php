<?php
/**
 * CyberSource payment form.
 *
 * Available variables (passed from the driver):
 * @var float  $totalToPay    Order amount
 * @var string $currencySymb  Currency symbol (e.g. €, $, R)
 * @var string $currencyCode  Currency ISO code (e.g. EUR, USD, ZAR)
 * @var string $custName      Customer full name
 * @var string $orderSid      Booking reference / SID
 * @var string $orderTs       Order timestamp
 * @var string $notifyUrl     VikRentCar notification URL
 * @var bool   $isSimulator   True if running in simulator mode
 * @var string $postUrl       CyberSource Secure Acceptance endpoint URL
 * @var array  $params        Signed form parameters (only when NOT simulator)
 *
 * @package VikRentCar_CyberSource
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="vrc-cs-container">
    <div class="vrc-cs-topbar">
        <div class="vrc-cs-topbar-left">
            <svg class="vrc-cs-topbar-lock" viewBox="0 0 20 20">
                <path d="M10 2a4 4 0 00-4 4v2H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-1V6a4 4 0 00-4-4zm2 6H8V6a2 2 0 114 0v2z"/>
            </svg>
            <span class="vrc-cs-topbar-title">Secure Payment</span>
        </div>
        <div class="vrc-cs-topbar-amount">
            <?php echo esc_html($currencySymb . ' ' . number_format($totalToPay, 2)); ?>
        </div>
    </div>

    <div class="vrc-cs-logos">
        <span class="vrc-cs-logo-text visa">VISA</span>
        <span class="vrc-cs-logo-text mc">Mastercard</span>
        <span style="font-size: 11px; color: #888; margin-left: auto;"> CyberSource</span>
    </div>

    <div class="vrc-cs-body">
        <?php if ($isSimulator) : ?>
            <!-- Show the test payment option without connecting to the bank. -->
            <div class="vrc-cs-sim-banner">
                <strong>TEST SIMULATOR MODE</strong>
                This is a local simulation. You can confirm this car rental booking without connecting to the bank.
            </div>

            <div style="background: #fafafa; border: 1px solid #eee; border-radius: 6px; padding: 14px; margin-bottom: 20px; font-size: 13px; line-height: 1.8;">
                <div><strong>Customer:</strong> <?php echo esc_html($custName); ?></div>
                <div><strong>Booking Ref:</strong> <?php echo esc_html($orderSid); ?></div>
                <div><strong>Total Amount:</strong> <?php echo esc_html($currencySymb . ' ' . number_format($totalToPay, 2) . ' ' . $currencyCode); ?></div>
            </div>

            <form method="POST" action="<?php echo esc_url($notifyUrl); ?>">
                <input type="hidden" name="cs_mode" value="simulator" />
                <input type="hidden" name="sid" value="<?php echo esc_attr($orderSid); ?>" />
                <input type="hidden" name="ts" value="<?php echo esc_attr($orderTs); ?>" />

                <button type="submit" class="vrc-cs-btn">
                    Complete Test Booking (Simulator)
                </button>
            </form>

        <?php else : ?>
            <!-- Show the booking details before sending the customer to CyberSource. -->
            <div style="background: #fafafa; border: 1px solid #eee; border-radius: 6px; padding: 14px; margin-bottom: 18px; font-size: 13px; line-height: 1.8;">
                <div><strong>Customer:</strong> <?php echo esc_html($custName); ?></div>
                <div><strong>Booking Reference:</strong> <?php echo esc_html($orderSid); ?></div>
                <div><strong>Total Due:</strong> <?php echo esc_html($currencySymb . ' ' . number_format($totalToPay, 2) . ' ' . $currencyCode); ?></div>
            </div>

            <form id="vrc-cs-sa-form" method="POST" action="<?php echo esc_url($postUrl); ?>">
                <?php foreach ($params as $k => $v) : ?>
                    <input type="hidden" name="<?php echo esc_attr($k); ?>" value="<?php echo esc_attr($v); ?>" />
                <?php endforeach; ?>

                <button type="submit" class="vrc-cs-btn">
                    Proceed to Card Payment &rarr;
                </button>
            </form>

            <div class="vrc-cs-security-note">
                <svg viewBox="0 0 20 20">
                    <path d="M10 2a4 4 0 00-4 4v2H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-1V6a4 4 0 00-4-4zm2 6H8V6a2 2 0 114 0v2z"/>
                </svg>
                <span>256-bit SSL &bull; 3D Secure / OTP Protected &bull; PCI DSS Certified</span>
            </div>
        <?php endif; ?>
    </div>
</div>